import { markupWithCodeExample, wrapStoryInContainer } from "./helpers";

export default {
  title: "components/Icons",
  decorators: [wrapStoryInContainer],
  parameters: {
    status: "beta",
    docs: {
      description: {
        component:
          "* Fontello files are not included in the master css for each theme. They are included under: `/dist/min/icons/[theme]/fontello/style.css`",
      },
    },
  },
};
export const Fontello1177 = () =>
  markupWithCodeExample([
    `<link href="/min/icons/1177/fontello/style.css" rel="stylesheet" />`,
    `<span aria-hidden="true" class="icon-print"></span>`,
    `<span aria-hidden="true" class="icon-enlarge-arrows"></span>`,
    `<span aria-hidden="true" class="icon-cancel"></span>`,
    `<span aria-hidden="true" class="icon-arrow"></span>`,
    `<span aria-hidden="true" class="icon-pdf"></span>`,
    `<span aria-hidden="true" class="icon-ppt"></span>`,
    `<span aria-hidden="true" class="icon-xls"></span>`,
    `<span aria-hidden="true" class="icon-doc"></span>`,
    `<span aria-hidden="true" class="icon-menu-x"></span>`,
    `<span aria-hidden="true" class="icon-map-pin-plus"></span>`,
    `<span aria-hidden="true" class="icon-info-full"></span>`,
    `<span aria-hidden="true" class="icon-phone"></span>`,
    `<span aria-hidden="true" class="icon-search"></span>`,
    `<span aria-hidden="true" class="icon-info"></span>`,
    `<span aria-hidden="true" class="icon-check"></span>`,
    `<span aria-hidden="true" class="icon-pointer"></span>`,
    `<span aria-hidden="true" class="icon-listview"></span>`,
    `<span aria-hidden="true" class="icon-blockview"></span>`,
    `<span aria-hidden="true" class="icon-link-ext"></span>`,
    `<span aria-hidden="true" class="icon-twitter"></span>`,
    `<span aria-hidden="true" class="icon-facebook"></span>`,
    `<span aria-hidden="true" class="icon-email-2"></span>`,
    `<span aria-hidden="true" class="icon-angle-right"></span>`,
    `<span aria-hidden="true" class="icon-angle-down"></span>`,
  ]);

export const FontelloInera = () =>
  markupWithCodeExample([
    `<link href="/min/icons/inera/fontello/style.css" rel="stylesheet" />`,
    `<span aria-hidden="true" class="icon-installningar"></span>`,
    `<span aria-hidden="true" class="icon-arrow"></span>`,
    `<span aria-hidden="true" class="icon-plus"></span>`,
    `<span aria-hidden="true" class="icon-minus"></span>`,
    `<span aria-hidden="true" class="icon-arrow-rigt-ext-circle"></span>`,
    `<span aria-hidden="true" class="icon-print"></span>`,
    `<span aria-hidden="true" class="icon-enlarge-arrows"></span>`,
    `<span aria-hidden="true" class="icon-cancel"></span>`,
    `<span aria-hidden="true" class="icon-arrow"></span>`,
    `<span aria-hidden="true" class="icon-pdf "></span>`,
    `<span aria-hidden="true" class="icon-ppt "></span>`,
    `<span aria-hidden="true" class="icon-xls "></span>`,
    `<span aria-hidden="true" class="icon-doc "></span>`,
    `<span aria-hidden="true" class="icon-menu-x"></span>`,
    `<span aria-hidden="true" class="icon-map-pin-plus"></span>`,
    `<span aria-hidden="true" class="icon-info-full"></span>`,
    `<span aria-hidden="true" class="icon-phone"></span>`,
    `<span aria-hidden="true" class="icon-search"></span>`,
    `<span aria-hidden="true" class="icon-info"></span>`,
    `<span aria-hidden="true" class="icon-check"></span>`,
    `<span aria-hidden="true" class="icon-pointer"></span>`,
    `<span aria-hidden="true" class="icon-listview"></span>`,
    `<span aria-hidden="true" class="icon-blockview"></span>`,
    `<span aria-hidden="true" class="icon-file"></span>`,
    `<span aria-hidden="true" class="icon-link-ext"></span>`,
    `<span aria-hidden="true" class="icon-twitter"></span>`,
    `<span aria-hidden="true" class="icon-facebook"></span>`,
    `<span aria-hidden="true" class="icon-email-2"></span>`,
    `<span aria-hidden="true" class="icon-angle-right"></span>`,
    `<span aria-hidden="true" class="icon-angle-down"></span>`,
  ]);

export const SVGIcons = () =>
  markupWithCodeExample([
    `
<div class="iu-svg-icon" style="width: 1rem; height: 1rem;">
  <svg viewBox="0 0 16 16" aria-hidden="true" focusable="false">
    <rect class="vert" height="16" width="2" y="0" x="7" />
    <rect height="2" width="16" y="7" x="0" />
  </svg>
</div>
`,
    `
<div class="iu-svg-icon" style="width: 1rem; height: 1rem;">
  <svg aria-hidden="true" focusable="false" class="iu-svg-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 15">
    <path fill="currentColor" d="M8.325 10.647L.585 3.259c-.78-.746-.78-1.954 0-2.7.782-.745 2.048-.745 2.83 0l9.153 8.738c.781.745.781 1.954 0 2.7l-9.154 8.737c-.78.746-2.047.746-2.828 0-.781-.745-.781-1.954 0-2.7l7.74-7.387z" transform="translate(-1290 -179) translate(410 141) rotate(90 432 470)"/>
  </svg>
</div>
`,
    `
<div class="iu-svg-icon" style="width: 1rem; height: 1rem;">
  <svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40">
    <path fill="currentColor" d="M26.046 14.925l3.485-3.486c.586-.585 1.536-.585 2.122 0 .585.586.585 1.536 0 2.122l-3.486 3.485-2.121 2.121-8.485 8.486c-.586.585-1.536.585-2.122 0-.585-.586-.585-1.536 0-2.122l8.486-8.485 2.12-2.121z" transform="translate(-663 -475) translate(90 386) translate(531 84) translate(42 5)"/>
    <path fill="currentColor" d="M14.096 23.096h3c.829 0 1.5.672 1.5 1.5 0 .829-.671 1.5-1.5 1.5h-7c-.828 0-1.5-.671-1.5-1.5 0-.828.672-1.5 1.5-1.5h4z" transform="translate(-663 -475) translate(90 386) translate(531 84) translate(42 5) rotate(45 13.596 24.596)"/>
  </svg>
</div>
`,
    `
<div class="iu-svg-icon" style="width: 1rem; height: 1rem;">
  <svg focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path fill="currentColor" d="M12 10.733l5.07-5.07c.35-.35.917-.35 1.267 0 .35.35.35.917 0 1.267L13.267 12l5.07 5.07c.35.35.35.917 0 1.267-.35.35-.917.35-1.267 0L12 13.267l-5.07 5.07c-.35.35-.917.35-1.267 0-.35-.35-.35-.917 0-1.267l5.07-5.07-5.07-5.07c-.35-.35-.35-.917 0-1.267.35-.35.917-.35 1.267 0l5.07 5.07z" transform="translate(-994 -650) translate(410 637) translate(584 13)"/>
  </svg>
</div>
`,
    `
<svg focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewBox="0 0 35 35">
  <path fill="#6A0032" d="M24.719 10.5c0-3.524-3.106-6.344-7.219-6.344-3.364 0-6.344 2.935-6.344 6.344 0 3.87 3.232 8.094 6.344 8.094 3.847 0 7.219-4.062 7.219-8.094zm1.312 0c0 4.709-3.9 9.406-8.531 9.406-3.925 0-7.656-4.875-7.656-9.406 0-4.138 3.571-7.656 7.656-7.656 4.811 0 8.531 3.377 8.531 7.656z" transform="translate(-1058 -171) translate(0 140) translate(1058 31)" />
  <g fill="#6A0032">
    <path d="M23.595 10.719c-.06-.194-.122-.398-.187-.62-.07-.234-.082-.277-.255-.879-.851-2.957-1.391-4.216-2.534-5.383-1.486-1.516-3.82-2.306-7.494-2.306-4.076 0-6.657.816-8.275 2.378C3.617 5.1 3.056 6.37 2.177 9.385l-.21.716c-.066.222-.127.426-.187.618h21.815zm-23.34.44c.146-.42.285-.86.454-1.431l.208-.71c.942-3.232 1.57-4.65 3.022-6.053C5.83 1.137 8.737.219 13.125.219c4 0 6.672.903 8.432 2.7 1.346 1.374 1.947 2.775 2.857 5.938l.253.872c.165.56.306 1.007.453 1.43.148.427-.169.872-.62.872H.875c-.451 0-.768-.445-.62-.871z" transform="translate(-1058 -171) translate(0 140) translate(1058 31) translate(5.25 21)" />
    <path d="M20.117 10.955c.07.355-.16.7-.516.771-.355.07-.7-.16-.771-.516l-.666-3.353c-.07-.356.16-.701.516-.772.355-.07.7.16.771.516l.666 3.354zM5.515 7.601c.07-.355.416-.586.771-.516.356.071.586.416.516.772l-.666 3.353c-.07.356-.416.587-.771.516-.356-.07-.587-.416-.516-.771L5.515 7.6z" transform="translate(-1058 -171) translate(0 140) translate(1058 31) translate(5.25 21)" />
  </g>
  <path fill="#C12143" d="M16.844 10.281H14c-.362 0-.656-.294-.656-.656 0-.362.294-.656.656-.656h3.5c.362 0 .656.294.656.656v3.719h1.094c.362 0 .656.294.656.656 0 .362-.294.656-.656.656H17.5c-.362 0-.656-.294-.656-.656v-3.719z" transform="translate(-1058 -171) translate(0 140) translate(1058 31)" />
</svg>
`,
    `
<svg focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40">
  <path fill="#6A0032" d="M25.288 26.94c-.293-.292-.293-.767 0-1.06.293-.293.768-.293 1.06 0l6.45 6.45c.128.134.366.353.666.57.385.28.754.462 1.053.509.234.037.396-.009.548-.161.154-.154.2-.318.162-.557-.048-.3-.23-.67-.506-1.054-.216-.3-.434-.54-.58-.68l-6.434-6.435c-.293-.293-.293-.768 0-1.06.293-.293.767-.293 1.06 0l6.422 6.422c.195.186.472.49.75.877.401.558.679 1.123.77 1.695.11.692-.072 1.342-.583 1.852-.509.51-1.155.69-1.842.583-.575-.09-1.141-.37-1.7-.777-.386-.28-.69-.558-.86-.74l-6.436-6.433z" transform="translate(-410 -292) translate(410 292) translate(2 2)"/>
  <path fill="#C12143" d="M25.496 15.96c0-.414.336-.75.75-.75s.75.336.75.75c0 6.086-4.95 11.036-11.035 11.036-6.086 0-11.036-4.95-11.036-11.036 0-6.086 4.95-11.035 11.036-11.035.414 0 .75.335.75.75 0 .414-.336.75-.75.75-5.258 0-9.536 4.278-9.536 9.535 0 5.258 4.278 9.536 9.536 9.536 5.257 0 9.535-4.278 9.535-9.536z" transform="translate(-410 -292) translate(410 292) translate(2 2)"/>
  <path fill="#6A0032" d="M15.96 29.53c7.482 0 13.57-6.088 13.57-13.57 0-7.481-6.088-13.57-13.57-13.57S2.39 8.48 2.39 15.96c0 7.482 6.088 13.57 13.57 13.57zm0 1.5C7.65 31.03.89 24.27.89 15.96S7.65.89 15.96.89s15.07 6.76 15.07 15.07-6.76 15.07-15.07 15.07z" transform="translate(-410 -292) translate(410 292) translate(2 2)"/>
</svg>
`,
    `
<svg focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40">
    <g fill="#6A0032">
        <path d="M14.836 35.592c.472-.422.999-.91 1.566-1.457 1.623-1.563 3.246-3.287 4.76-5.117 3.209-3.882 5.478-7.7 6.396-11.23.293-1.125.443-2.208.443-3.244 0-1.38-.217-2.733-.636-4.023-1.185-3.631-3.937-6.597-7.49-8.086C18.25 1.755 16.5 1.4 14.7 1.4 7.366 1.4 1.4 7.299 1.4 14.544c0 1.036.15 2.119.443 3.245.918 3.53 3.187 7.347 6.397 11.229 1.513 1.83 3.136 3.554 4.759 5.117.567.547 1.094 1.035 1.566 1.457l.135.12.136-.12zm-.586 1.584c-.115-.097-.325-.279-.618-.54-.484-.433-1.024-.933-1.605-1.493-1.658-1.598-3.317-3.359-4.866-5.233-3.329-4.026-5.694-8.005-6.673-11.769C.166 16.904 0 15.704 0 14.544 0 6.522 6.596 0 14.7 0c1.986 0 3.92.392 5.716 1.144 3.927 1.646 6.968 4.923 8.28 8.944.465 1.429.705 2.928.705 4.456 0 1.16-.166 2.36-.488 3.597-.979 3.764-3.345 7.743-6.673 11.769-1.55 1.874-3.208 3.635-4.866 5.233-.581.56-1.12 1.06-1.606 1.493-.292.261-.502.443-.617.54-.26.219-.64.219-.901 0z" transform="translate(-410 -342) translate(410 342) translate(6 2)"/>
        <path d="M15.77 29.812c1.022-1.059 2.044-2.178 2.997-3.308.715-.847 1.362-1.667 1.926-2.448.704-.975 1.266-1.87 1.66-2.664.173-.346.593-.487.94-.315.345.172.486.593.314.939-.433.87-1.033 1.828-1.78 2.86-.585.811-1.254 1.658-1.99 2.53-.975 1.156-2.017 2.299-3.06 3.379-.365.378-.704.72-1.008 1.023l-.387.38c-.13.125-.304.195-.485.195h-.112c-.181 0-.355-.07-.485-.195-.072-.07-.204-.198-.387-.38-.305-.302-.644-.646-1.009-1.024-1.042-1.08-2.085-2.222-3.06-3.378-.736-.873-1.404-1.72-1.99-2.531-.747-1.034-1.347-1.992-1.78-2.863-.173-.346-.032-.767.315-.939.346-.172.766-.03.938.316.395.794.957 1.69 1.662 2.666.564.78 1.21 1.6 1.926 2.448.952 1.13 1.974 2.25 2.997 3.309.334.347.646.663.929.944.282-.28.594-.597.929-.944z" transform="translate(-410 -342) translate(410 342) translate(6 2)"/>
    </g>
    <path fill="#C12143" d="M20.5 20.75c3.452 0 6.25-2.798 6.25-6.25s-2.798-6.25-6.25-6.25-6.25 2.798-6.25 6.25 2.798 6.25 6.25 6.25zm0-1.5c-2.623 0-4.75-2.127-4.75-4.75s2.127-4.75 4.75-4.75 4.75 2.127 4.75 4.75-2.127 4.75-4.75 4.75z" transform="translate(-410 -342) translate(410 342)"/>
</svg>`,
    `<svg focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="40" height="40" viewBox="0 0 40 40">
  <defs>
      <filter id="rv1wk04w1b" width="132%" height="124.3%" x="-16%" y="-12.1%" filterUnits="objectBoundingBox">
          <feGaussianBlur in="SourceAlpha" result="shadowBlurInner1" stdDeviation="1.5"/>
          <feOffset dy="1" in="shadowBlurInner1" result="shadowOffsetInner1"/>
          <feComposite in="shadowOffsetInner1" in2="SourceAlpha" k2="-1" k3="1" operator="arithmetic" result="shadowInnerInner1"/>
          <feColorMatrix in="shadowInnerInner1" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.5 0"/>
      </filter>
      <path id="lj16gh0i3a" d="M4.266 13.066c.994-.574 2.28-.266 2.884.7.615.983.284 2.26-.725 2.848l-2.594 1.515c-.358.209-.817.088-1.026-.27-.209-.357-.088-.816.27-1.025l2.595-1.516c.284-.165.37-.498.209-.757-.173-.275-.563-.369-.862-.196-.21.12-.446.191-.688.205-.836.05-1.567-.574-1.619-1.421-.036-.88.15-1.756.542-2.549 1.008-2.06 3.06-3.458 5.477-3.69 2.266-.2 4.477.89 5.647 2.808 1.678 2.747.72 6.284-2.124 7.886-1.275.726-2.046 1.489-3 2.842-.204.291-.982 1.44-.965 1.415-.317.465-.615.798-.998 1.059-.903.613-2.171.625-3.087.03-.347-.226-.446-.69-.22-1.038.226-.347.69-.445 1.038-.22.41.267 1.023.26 1.426-.013.198-.135.381-.34.602-.664-.023.034.764-1.128.978-1.433 1.071-1.52 1.995-2.433 3.487-3.283 2.112-1.19 2.815-3.782 1.583-5.8-.87-1.426-2.531-2.245-4.326-2.09-1.799.176-3.393 1.261-4.172 2.853-.282.57-.415 1.196-.39 1.81.043 0 .052-.002.058-.006z"/>
  </defs>
  <g fill="none" fill-rule="evenodd">
    <path fill="#6A0032" d="M.488 29.612c-.303-.283-.319-.758-.036-1.06.283-.302.758-.318 1.06-.035C2.521 29.46 3.971 30.189 5 30.25h1.003c1.784.007 3.751-1.511 4.268-3.296 1.2-4.999 2.26-6.465 4.398-7.272 5.162-2.538 7.122-8.052 4.7-12.47-2.438-3.805-6.257-5.798-10.29-5.466-3.056.321-5.766 1.939-7.452 4.505-.228.346-.693.442-1.039.214-.346-.227-.442-.692-.215-1.038C2.31 2.48 5.423.622 8.938.253c4.618-.381 8.963 1.888 11.72 6.193 2.87 5.234.581 11.678-5.392 14.61-1.68.638-2.442 1.69-3.545 6.281C11.01 29.791 8.46 31.76 6 31.75l-1.044-.001c-1.459-.085-3.223-.971-4.468-2.137z" transform="translate(-410 -242) translate(410 242) translate(8 3)"/>
    <g transform="translate(-410 -242) translate(410 242) translate(8 3)">
        <use fill="#C12143" xlink:href="#lj16gh0i3a"/>
        <use fill="#000" filter="url(#rv1wk04w1b)" xlink:href="#lj16gh0i3a"/>
    </g>
    <path fill="#6A0032" d="M17.357 23.821c.007-.414.349-.744.763-.736.414.007.744.349.736.763-.037 2.097-1.717 3.777-3.764 3.736-.415-.008-.744-.35-.735-.765.008-.414.35-.743.765-.735 1.204.024 2.212-.983 2.235-2.263zM20.872 24.465c.007-.414.349-.744.763-.736.414.007.744.35.736.763-.069 3.785-3.091 6.807-6.764 6.736-.414-.009-.743-.35-.735-.765.008-.414.35-.743.764-.735 2.831.055 5.181-2.295 5.236-5.263z" transform="translate(-410 -242) translate(410 242) translate(8 3)"/>
    <path fill="#6A0032" d="M24.387 25.11c.008-.415.35-.745.764-.737.414.007.744.35.736.763-.1 5.474-4.466 9.839-9.765 9.735-.414-.008-.743-.35-.735-.765.008-.414.35-.743.765-.735 4.457.088 8.15-3.605 8.235-8.262z" transform="translate(-410 -242) translate(410 242) translate(8 3)"/>
  </g>
</svg>
`,
    `
<svg focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40">
  <path fill="#6A0032" d="M20 17.379l8.485-8.486c.586-.585 1.536-.585 2.122 0 .585.586.585 1.536 0 2.122L22.12 19.5l8.486 8.485c.585.586.585 1.536 0 2.122-.586.585-1.536.585-2.122 0L20 21.62l-8.485 8.486c-.586.585-1.536.585-2.122 0-.585-.586-.585-1.536 0-2.122L17.88 19.5l-8.486-8.485c-.585-.586-.585-1.536 0-2.122.586-.585 1.536-.585 2.122 0L20 17.38z" transform="translate(-410 -442) translate(410 442)"/>
</svg>
`,
    `
<svg focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="27" height="27" viewBox="0 0 27 27">
  <g fill="#6A0032" fill-rule="nonzero">
    <path d="M.293 1.707l24.749 24.749c.39.39 1.023.39 1.414 0 .39-.39.39-1.024 0-1.414L1.707.292c-.39-.39-1.024-.39-1.414 0-.39.391-.39 1.025 0 1.415z" transform="translate(-417 -398) translate(417 398)"/>
    <path d="M.293 1.958l24.749 24.75c.39.39 1.023.39 1.414 0 .39-.391.39-1.025 0-1.415L1.707.544C1.317.154.683.154.293.544c-.39.39-.39 1.024 0 1.414z" transform="translate(-417 -398) translate(417 398) matrix(1 0 0 -1 0 27.251)"/>
  </g>
</svg>
`,
    `
<svg focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="31" height="27" viewBox="0 0 31 27">
  <g fill="#3B4266" fill-rule="nonzero">
    <path d="M4.85 7.895H6.879999999999999V9.924999999999999H4.85z" transform="translate(-735 -949) translate(735.5 949)"/>
    <path d="M2.876.744h24.248c1.177 0 2.132.955 2.132 2.132v21.203c0 1.177-.955 2.132-2.132 2.132H2.876c-1.177 0-2.132-.955-2.132-2.132V2.876C.744 1.699 1.7.744 2.876.744zm0 1.106c-.567 0-1.026.46-1.026 1.026v21.203c0 .567.46 1.026 1.026 1.026h24.248c.567 0 1.026-.46 1.026-1.026V2.876c0-.567-.46-1.026-1.026-1.026H2.876z" transform="translate(-735 -949) translate(735.5 949)"/>
    <path d="M1.573 5.047L29.155 5.047 29.155 3.941 1.573 3.941zM7.895 7.895H9.924999999999999V9.924999999999999H7.895zM10.94 7.895H12.969999999999999V9.924999999999999H10.94zM13.985 7.895H16.015V9.924999999999999H13.985zM17.03 7.895H19.060000000000002V9.924999999999999H17.03zM20.075 7.895H22.105V9.924999999999999H20.075zM23.12 7.895H25.150000000000002V9.924999999999999H23.12zM4.85 10.94H6.879999999999999V12.969999999999999H4.85zM7.895 10.94H9.924999999999999V12.969999999999999H7.895zM10.94 10.94H12.969999999999999V12.969999999999999H10.94zM13.985 10.94H16.015V12.969999999999999H13.985zM17.03 10.94H19.060000000000002V12.969999999999999H17.03zM20.075 10.94H22.105V12.969999999999999H20.075zM23.12 10.94H25.150000000000002V12.969999999999999H23.12zM4.85 13.985H6.879999999999999V16.015H4.85zM7.895 13.985H9.924999999999999V16.015H7.895zM10.94 13.985H12.969999999999999V16.015H10.94zM13.985 13.985H16.015V16.015H13.985zM17.03 13.985H19.060000000000002V16.015H17.03zM20.075 13.985H22.105V16.015H20.075zM23.12 13.985H25.150000000000002V16.015H23.12zM23.12 17.03H25.150000000000002V19.060000000000002H23.12zM4.85 17.03H6.879999999999999V19.060000000000002H4.85zM7.895 17.03H9.924999999999999V19.060000000000002H7.895zM10.94 17.03H12.969999999999999V19.060000000000002H10.94zM4.85 20.075H6.879999999999999V22.105H4.85zM7.895 20.075H9.924999999999999V22.105H7.895zM10.94 20.075H12.969999999999999V22.105H10.94zM13.985 17.03H16.015V19.060000000000002H13.985zM17.03 17.03H19.060000000000002V19.060000000000002H17.03zM20.075 17.03H22.105V19.060000000000002H20.075z" transform="translate(-735 -949) translate(735.5 949)"/>
  </g>
</svg>
`,
    `
<svg focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 15 15">
  <g fill="#396291" fill-rule="nonzero" stroke="#396291" stroke-width=".5">
    <path d="M12.385 7.513c0-.211.172-.383.384-.383.211 0 .383.172.383.383 0 3.11-2.53 5.639-5.639 5.639-3.109 0-5.638-2.53-5.638-5.639 0-3.109 2.529-5.638 5.638-5.638.212 0 .384.172.384.383 0 .212-.172.383-.384.383-2.686 0-4.872 2.186-4.872 4.872 0 2.687 2.186 4.872 4.872 4.872 2.687 0 4.872-2.185 4.872-4.872z" transform="translate(-743 -457) translate(743 457)"/>
      <g>
        <path d="M6.64.11l1.313 1.312c.146.147.146.384 0 .53L6.64 3.266c-.146.147-.384.147-.53 0-.147-.146-.147-.384 0-.53l.672-.673H.536c-.207 0-.375-.167-.375-.374 0-.208.168-.375.375-.375l6.246-.001L6.11.64c-.147-.146-.147-.384 0-.53.146-.147.384-.147.53 0z" transform="translate(-743 -457) translate(743 457) rotate(-45 11.222 -3.333)"/>
      </g>
  </g>
</svg>
`,
  ]);
